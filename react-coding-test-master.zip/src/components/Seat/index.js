import Seat from './Seat';
export default Seat;
