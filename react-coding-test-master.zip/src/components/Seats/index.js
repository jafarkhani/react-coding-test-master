import Seats from './Seats';
export default Seats;
